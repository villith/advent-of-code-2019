# RestedXP Guides

## [v4.3.12](https://github.com/RestedXP/RXPGuides/tree/v4.3.12) (2022-10-01)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.3.11...v4.3.12) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- northrend farm guides update  
